# System State Export

Generated: 20250907_180541

## Components

### ai_system (Success)

- Files: 0
- Directories: 7
- Total Size: 118 bytes

### database (Success)

- Files: 0
- Directories: 0
- Total Size: 0 bytes

### mcp_integration (Success)

- Files: 0
- Directories: 4
- Total Size: 98 bytes

### critical_files (Success)

- Files: 4
- Directories: 0
- Total Size: 6879 bytes

## Statistics

- Total Files: 4
- Total Size: 7095 bytes
- Automated Items: 4
- Manual Items: 7
- Warnings: 0
- Errors: 1
